﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Логика взаимодействия для Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        List<Test> listtests = new List<Test>();
        List<Checkontrue> checkontrues = new List<Checkontrue>();
        private int counter = 3;
        public int currenttest = -1;
        Checkontrue ctrue = new Checkontrue();

        Test test = new Test();
        public Window4()
        {
            InitializeComponent();

            BinaryFormatter binform = new BinaryFormatter();
            using (FileStream file = new FileStream("saved.bin", FileMode.OpenOrCreate, FileAccess.Read))
            {
                listtests = ((List<Test>)binform.Deserialize(file));
                this.DataContext = listtests[0];
            }

            if (Check11.IsChecked == true) { ctrue.Checkboolfirst = true; }
           

            if (Check22.IsChecked == true) { ctrue.Checkboolsecond = true; }
          

            if (Check33.IsChecked == true)
            {
                ctrue.Checkboolthird = true;
            }
          

            if (Check44.IsChecked == true)
            { ctrue.Checkboolfourth = true; }
           

            if (Check22.IsChecked == true)
            { ctrue.Checkboolfifth = true; }
            

            checkontrues.Add(ctrue);

        }

        private void buttonrightt_Click(object sender, RoutedEventArgs e)
        {
            if (currenttest == -1)
            {
                this.DataContext = listtests.FirstOrDefault();
                currenttest = 0;

            }
            else if (currenttest == 0)
            {
                this.DataContext = listtests.LastOrDefault();
                currenttest = listtests.Count - 1;

            }
            else
            {
                this.DataContext = listtests[currenttest-- - 1];
            }
        }

        private void buttonleftt_Click(object sender, RoutedEventArgs e)
        {
            if (currenttest == -1 || currenttest == listtests.Count - 1)
            {
                this.DataContext = listtests.FirstOrDefault();
                currenttest = 0;
            }
            else
            {
                this.DataContext = listtests[++currenttest];
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //if (Check11.IsChecked == true) { ctrue.Checkboolfirst = true; }


            //if (Check22.IsChecked == true) { ctrue.Checkboolsecond = true; }


            //if (Check33.IsChecked == true)
            //{
            //    ctrue.Checkboolthird = true;
            //}


            //if (Check44.IsChecked == true)
            //{ ctrue.Checkboolfourth = true; }


            //if (Check22.IsChecked == true)
            //{ ctrue.Checkboolfifth = true; }


            //checkontrues.Add(ctrue);
        }

        private void Check22_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
    public class Checkontrue
        {
      public   Checkontrue() { }
        public bool Checkboolfirst { get; set; }
        public bool Checkboolsecond { get; set; }
        public bool Checkboolthird { get; set; }
        public bool Checkboolfourth { get; set; }
        public bool Checkboolfifth { get; set; }



        public Checkontrue( bool check1, bool check2, bool check3, bool check4, bool check5)
        {
            
            this.Checkboolfirst = check1;
            this.Checkboolsecond = check2;
            this.Checkboolthird = check3;
            this.Checkboolfourth = check4;
            this.Checkboolfifth = check5;
        }
    }
    
}
